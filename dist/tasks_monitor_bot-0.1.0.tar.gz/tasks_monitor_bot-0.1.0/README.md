# telegram_bot_package

A package to run tasks and send status messages to Telegram.

## Installation

```bash
pip install telegram_bot_package

